package ua.mysmArthome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySmArtHomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
